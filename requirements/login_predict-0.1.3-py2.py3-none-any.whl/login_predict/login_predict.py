import math


class LoginPredict:

    @classmethod
    def predict(cls, x_1: float, x_2: float, x_3: float, x_4: float, is_verified_login: bool):
        bias = 0.623
        w_1 = 2.734
        w_2 = 0.263
        w_3 = -4.342
        w_4 = 0.234

        Z = bias + x_1 * w_1 + x_2 * w_2 + x_3 * w_3 + x_4 * w_4

        fraud_score = 1.0 / (1.0 + math.exp(-Z))
        print("0.1.3")

        if is_verified_login:
            return 0.0
        else:
            return fraud_score
