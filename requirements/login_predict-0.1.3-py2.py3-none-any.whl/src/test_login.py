def predict(x):
    return "Hi"