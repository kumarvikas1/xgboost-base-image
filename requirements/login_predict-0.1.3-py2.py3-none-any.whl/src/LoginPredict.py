class loginPredict:

    @classmethod
    def predict(self):
        return ""